# Toan-Roi-Rac-1-va-2-full-codeva-ly-thuyet
Cám ơn các bạn đã click tài khoản github này thay vì hàng triệu cái ngoài kia . Đây là 2 môn Trr1 và trr2 . mình cũng A+ 2 môn này , đúc đk 1 số kinh nghiệm . 

Hy vọng nó giúp bạn đọc học nhanh hơn và A+ giống như mình . hehe. 
Nếu muốn contact mình hay cảm ơn mình thì :

fb: https://www.facebook.com/huyinit13

youtube bài giảng :https://www.youtube.com/channel/UCgktVJ2PAuA3zHSR1A-K20w

youtube vlog :https://www.youtube.com/channel/UCskOQJ8MIQXTAQ_jGryJNcQ
